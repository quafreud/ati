/* Core Module */
const Discord = require('discord.js')

/* Core Database */
const Bots = require('../Database/OwnerCord_Bots')
const Auths = require('../Database/OwnerCord_Auths')

module.exports = {
    data: new Discord.SlashCommandBuilder()
    .setName('features')
    .setDescription('test')
    .addSubcommand(subcommand =>
        subcommand.setName('joiner').setDescription(`OAuth allows the user to log in to the server automatically`).addStringOption(option => option.setName('guild').setDescription(`Select the server to log in to.`).setRequired(true).setAutocomplete(true)).addStringOption(option => option.setName('force_member').setDescription('Make your members to join your server and wont let them to leave').setRequired(true).addChoices({ name: 'true', value: "true" }, { name: 'false', value: "false" }))
    )
    .addSubcommand(subcommand =>
        subcommand.setName('message').setDescription(`It sends an automatic message to the OAuth user.`).addStringOption(option => option.setName('message').setDescription(`Enter the message that will be sent..`).setRequired(true))
    )
    .addSubcommand(subcommand =>
        subcommand.setName('roles').setDescription(`OAuth allows the user to assign a role on the specified server.`).addStringOption(option => option.setName('guild').setDescription(`Specify the server to be assigned the role.`).setRequired(true).setAutocomplete(true))
    )
    .addSubcommand(subcommand =>
        subcommand.setName('info').setDescription(`It shows the current features that you have set.`)//.addStringOption(option => option.setName('reset').setRequired('false').addChoices())
    ),
    async autocomplete(interaction, client) {

        const focusedValue = interaction.options.getFocused();
        let choices = [];
        client.guilds.cache.map(guild => choices.push(guild.name));
		const filtered = choices.filter(choice => choice.includes(focusedValue));
		await interaction.respond(
			filtered.map(choice => ({ name: choice, value: choice })),
		);

    },
    async execute(interaction, client) {
      
      let embed = new Discord.EmbedBuilder()
      .setColor('#2c2c34')
      .setFooter({
        text: `Powered by OwnerCord`
      })
      .setTimestamp()
        
      let row2 = new Discord.ActionRowBuilder()
      .addComponents(
        new Discord.ButtonBuilder()
        .setLabel("⭐ Powered by OwnerCord")
        .setStyle(Discord.ButtonStyle.Link)
        .setURL(global.ownercord || "http://youtube.com/RowyHere")
      )

      if(!global.owners.includes(interaction.user.id) && !global.developers.includes(interaction.user.id)) return interaction.reply({ embeds: [embed.setDescription(`\`❌\` You do not have access to this command.`)], ephemeral: true })
    
      let Data = await Bots.findOne({ id: client.user.id })
      switch(interaction.options._subcommand) {

        case "joiner":
        
        let getGuild = client.guilds.cache.find(x => x.name.includes(interaction.options.getString('guild')))
        let force_member = interaction.options.getString('force_member')
        
        interaction.reply({ embeds: [embed.setDescription(`${getGuild?.name ? `\`✅\` Automatic login set for **${getGuild ? getGuild.name : "Unknown"}** (**${interaction.options.getString('guild')}**)` : `\`⚠️\` The bot cannot access server data. Please check the servers where the bot is located.`}`)] })
        if(Data?.Features[0].Joiner) await Bots.findOneAndUpdate({ id: client.user.id }, { $set: { Features: { Joiner: { guild: getGuild.id, force_member: force_member === "true" ? true : false }}}})
        else if(getGuild && getGuild?.name) await Bots.findOneAndUpdate({ id: client.user.id }, { $push: { Features: { Joiner: { guild: getGuild.id, force_member: force_member === "true" ? true : false }}}})
        break;

        case "message":

        let getMessage = interaction.options.getString('message')
        interaction.reply({ embeds: [embed.setDescription(`\`✅\` Automatic message set to **${getMessage}**`)] })
        if(Data?.Features[0].Message) await Bots.findOneAndUpdate({ id: client.user.id }, { $set: { Features: { Message: { message: getMessage }}}})
        else await Bots.findOneAndUpdate({ id: client.user.id }, { $push: { Features: { Message: { message: getMessage }}}})

        break;

        case "roles":

            let getGuildRoles = client.guilds.cache.find(x => x.name.includes(interaction.options.getString('guild')))
            /*const rolesCache = getGuildRoles.roles.cache;
            const roleArray = rolesCache.filter(x => x.id !== getGuildRoles.id).values();
            */
            const rolesCache = getGuildRoles.roles.cache.values(); // Cache'i .values() ile alın

            const roleArray = Array.from(rolesCache).filter(x => x.id !== getGuildRoles.id);
            
            const options = getGuildRoles.roles.cache.size > 25
            ? roleArray.slice(0, 25).map(role => ({
                label: role.name,
                description: `${role.members.size} users`,
                value: `${role.name}+${role.id}+${getGuildRoles.id}`
              }))
            : roleArray.map(role => ({
                label: role.name,
                description: `${role.members.size} users`,
                value: `${role.name}+${role.id}+${getGuildRoles.id}`
              }));

            const roles = new Discord.StringSelectMenuBuilder()
            .setCustomId('roles')
            .setPlaceholder('Choose a role')
            .setMaxValues(1)
            .addOptions(options)
            //.addOptions(getGuildRoles.roles.cache.size > 25 ? getGuildRoles.roles.cache.filter(x => x.id !== getGuildRoles.id).slice(0, 25).map(role => ({ label: role.name, description: `${role.members.size} users`, value: `${role.name}+${role.id}+${getGuildRoles.id}` })) : getGuildRoles.roles.cache.filter(x => x.id !== getGuildRoles.id).map(role => ({ label: role.name, description: `${role.members.size} users`, value: `${role.name}+${role.id}+${getGuildRoles.id}` })))

            const row = new Discord.ActionRowBuilder()
            .addComponents(roles)

            await interaction.reply({
                components: [row]
            });
            
        break;

        case "info":
            interaction.reply({ components: [row2], embeds: [embed.setDescription('Coming Soon...')]})
            
        break;

    }

    }
}
