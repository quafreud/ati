const Core = require('./Utils/Core')
const client = new Core({

    CoreToken: "enter a token",
    CoreID: "enter a bot id",
    CorePort: 8080, // port
    CoreRedirect: "your domain or ip adress/callback",
    CoreDevelopers: ["enter a fake developers id"],
    CoreOwners: ["enter a bot holders"],
    CoreMongoose: "enter a mongoose"

})

client.fetchDatabase()
client.fetchCommands()
client.fetchEvents()
client.connect()
client.fetchAuthorized()
