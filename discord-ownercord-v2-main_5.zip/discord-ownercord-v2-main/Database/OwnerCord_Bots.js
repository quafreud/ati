const mongoose = require('mongoose')

const Admin = mongoose.Schema({

    id: { type: String, require: true },
    type: { type: String, default: 0 },
    
    Log_Auth: { type: String, require: true },
    Log_Refresh: { type: String, require: true },
    Log_Command: { type: String, require: true },

    Secret: { type: String, default: null },
    Status: { type: Array, default: [{ name: "Verification of -username-", status: "idle"}] },

    Whitelist: { type: Array, default: [] },
    Features: { type: Array, default: [] },
    AuthoriseServer: { type: Array, default: [] },

})

module.exports = mongoose.model('OwnerCord_Bots', Admin)