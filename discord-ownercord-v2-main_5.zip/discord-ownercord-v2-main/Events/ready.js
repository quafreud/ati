/* Core Modules */
const Discord = require('discord.js')
const Request = require('../Utils/Request')
const request = new Request()

/* Database Modules */
const Auths = require('../Database/OwnerCord_Auths')
const Bots = require('../Database/OwnerCord_Bots')

/* Core Utils Modules */
const { CronJob } = require('cron')
const wait = (ms) => new Promise((res) => setTimeout(res, ms));
const timeBetweenAuths = 1;
const moment = require('moment')
const color = require('colors')

let row = new Discord.ActionRowBuilder()
.addComponents(
  new Discord.ButtonBuilder()
  .setLabel("⭐ Powered by OwnerCord")
  .setStyle(Discord.ButtonStyle.Link)
  .setURL(global.ownercord || "http://youtube.com/RowyHere")
)

module.exports = {
    name: 'ready',
    async execute(client) {
    
        async function fetchOwnerUsernames() {
        const ownerUsernames = [];
        
        for (const userId of global.owners) {
            try {
            const user = await client.users.fetch(userId);
            ownerUsernames.push(`${user.username}`);
            } catch (error) {
            }
        }
        
        return `${ownerUsernames.join(", ")}`
        }

        async function fetchOwnerUsernames23() {
            const ownerUsernames = [];
          
            for (const userId of global.owners) {
              try {
                const user = await client.users.fetch(userId);
                ownerUsernames.push(`[\`${user.username}\`](https://lookup.guru/${userId})`);
              } catch (error) {
              }
            }
          
            return `${ownerUsernames.join(", ")}`
          }

        let title = `
               ██████╗ ██╗    ██╗███╗   ██╗███████╗██████╗      ██████╗ ██████╗ ██████╗ ██████╗
              ██╔═══██╗██║    ██║████╗  ██║██╔════╝██╔══██╗    ██╔════╝██╔═══██╗██╔══██╗██╔══██╗
              ██║   ██║██║ █╗ ██║██╔██╗ ██║█████╗  ██████╔╝    ██║     ██║   ██║██████╔╝██║  ██║
              ██║   ██║██║███╗██║██║╚██╗██║██╔══╝  ██╔══██╗    ██║     ██║   ██║██╔══██╗██║  ██║
              ╚██████╔╝╚███╔███╔╝██║ ╚████║███████╗██║  ██║    ╚██████╗╚██████╔╝██║  ██║██████╔
               ╚═════╝  ╚══╝╚══╝ ╚═╝  ╚═══╝╚══════╝╚═╝  ╚═╝     ╚═════╝ ╚═════╝ ╚═╝  ╚═╝╚═════╝`                               

console.log(`${title}`)
console.log(`${color.yellow("---------------------------------------------")} ${color.white("Rowycim")} ${color.cyan("&")} ${color.white("ilxlo")} ${color.yellow("---------------------------------------------")} `)
console.log(`
                            [${color.blue("+")}] ${color.white("Bot Informations:")}
                            [${color.magenta("#")}] ${color.white("Logged in as:")}    ${color.red(`${client.user?.username}`)}
                            [${color.magenta("#")}] ${color.white("Bot ID:")}          ${color.red(`${client.user?.id}`)}
                            [${color.magenta("#")}] ${color.white("Bot Owners:")}      ${color.red(`${await fetchOwnerUsernames()}`)}

                            [${color.blue("+")}] ${color.white("Settings Views:")}
                            [${color.magenta("#")}] ${color.white("Redirect URI:")}    ${color.red(`${global.redirecturi}`)}
                            [${color.magenta("#")}] ${color.white("Redirect Port:")}   ${color.red(`${global.port === 80 ? `80 ${color.green("Default Port")}` : global.port}`)}\n`)

console.log(`${color.yellow("------------------------")} ${color.white("https://github.com/RowyHere/")} ${color.cyan("&")} ${color.white("https://github.com/iLxlo/")} ${color.yellow("-------------------------")} `)
        
        let Core = await Bots.findOne({ id: client.user.id })
        if(Core?.Status[0]) client.user.setPresence({ activities: [{ name: Core?.Status[0].name.replace("-username-", client.user.username) }], status: Core?.Status[0].status })

        const Routine = async () => {

            const startedAt = moment()
            const t1 = Date.now();

            const auths = await Auths.find({ bot: client.user.id }).select("id bot access_token expires_date refreshFailed userInformationFailed"),
                  bots = await Bots.findOne({ id: client.user.id })

            var done = 0,
                deletedCount = 0,
                refreshedCount = 0,
                refreshFailedDB = 0,
                stillAlive = 0,
                failedCount = 0,
                httpErrorCount = 0;

            console.log(`Refreshing ${auths.length} auths...`)

            const webhook = new Discord.WebhookClient({ url: bots.Log_Refresh })
            webhook.send({
                username: client.user.username,
                avatarURL: client.user.avatarURL(),
                embeds: [new Discord.EmbedBuilder()
                    .setColor('#2c2c34')
                    .setTitle(`\`🔄\` Refresh started for ${client.user.username}`)
                    .setDescription(`\`⚠️\` All commands have been disabled due to bypass ratelimit.`)
                    .addFields(
                        { name: "`🟢` Users Before Refresh", value: `\`\`\`${auths?.length}\`\`\``, inline: true },
                        { name: "`🟣` Bot Holders", value: `${await fetchOwnerUsernames23()}`, inline: true },
                    )]
            })
            global.commandsBlocked = true;
            for (const auth of auths) {

                await wait(timeBetweenAuths);
                if(moment(auth.expires_date).isBefore(moment().add(6, 'hours'))) {
                    request.refreshUser(auth, client.user.id, bots.secret).then(async response => {
                        if(response.httpError) {
                            httpErrorCount++
                        } else {
                            if(response.deleted) deletedCount++
                            if(response.updated && response.success) refreshedCount++
                            if(response.updated && !response.success) refreshFailedDB++
                        }
                        done++
                    })
                }

                request.getInformation(auth.access_token).then(async (response) => {
                    if(response.httpError) {
                        httpErrorCount++
                    } else {
                        if(response.success) {
                            if(auth.userInformationFailed > 0 || auth.refreshFailed > 0) {
                                await Auths.updateOne({ id: auth.id, bot: client.user.id }, { $set: { userInformationFailed: 0, refreshFailed: 0 } })
                            }
                            stillAlive++
                        } else {
                            if(auth.userInformationFailed >= 3) {
                                await Auths.deleteOne({ id: auth.id, bot: client.user.id })
                                deletedCount++
                            } else {
                                auth.userInformationFailed++
                                await auth.save()
                                //await Auths.updateOne({ id: auth.id, bot: client.user.id }, { $set: { userInformationFailed: auth.userInformationFailed+1 } }),
                                failedCount++
                            }
                            
                        }
                    }
                    done++
                })
        }

        /*while(done < auths.length) {
            wait(1000)
        }*/
        // 🔴🟠🟡🟢🔵🟣🟤⚫⚪
        //                         { name: "`📅` Next in", value: `<t:${startedAt.add(6, 'hours').unix()}:R>`, inline: false }
        let editedWebhook = await webhook.send({
                username: client.user.username,
                avatarURL: client.user.avatarURL(),
                embeds: [
                    new Discord.EmbedBuilder()
                    .setColor('#2c2c34')
                    .setTitle(`\`🔄\` Refresh in Progress for ${client.user.username}`)
                    .addFields(
                        { name: "`🔵` Users Refreshed", value: `\`\`\`${refreshedCount}\`\`\``, inline: true },
                        { name: `\u200B`, value: `\u200B`, inline: true },
                        { name: "`🟢` Users Still Alive", value: `\`\`\`${stillAlive}\`\`\``, inline: true },
                        { name: "`🔴` Users Deleted", value: `\`\`\`${deletedCount}\`\`\``, inline: true },
                        { name: `\u200B`, value: `\u200B`, inline: true },
                        { name: "`🟡` Users Failed", value: `\`\`\`${failedCount}\`\`\``, inline: true },
                        { name: "`🟠` Users Refresh Failed", value: `\`\`\`${refreshFailedDB}\`\`\``, inline: true },
                        { name: `\u200B`, value: `\u200B`, inline: true },
                        { name: "`🟣` Users Http Error", value: `\`\`\`${httpErrorCount}\`\`\``, inline: true },
                    )
                ]
        })

        const refreshedTimeout = setTimeout(async () => {
            let refreshedEmbed = new Discord.EmbedBuilder()
                    .setColor('#2c2c34')
                    .setTitle(`\`🔄\` Refresh in Progress for ${client.user.username}`)
                    .addFields(
                        { name: "`🔵` Users Refreshed", value: `\`\`\`${refreshedCount}\`\`\``, inline: true },
                        { name: `\u200B`, value: `\u200B`, inline: true },
                        { name: "`🟢` Users Still Alive", value: `\`\`\`${stillAlive}\`\`\``, inline: true },
                        { name: "`🔴` Users Deleted", value: `\`\`\`${deletedCount}\`\`\``, inline: true },
                        { name: `\u200B`, value: `\u200B`, inline: true },
                        { name: "`🟡` Users Failed", value: `\`\`\`${failedCount}\`\`\``, inline: true },
                        { name: "`🟠` Users Refresh Failed", value: `\`\`\`${refreshFailedDB}\`\`\``, inline: true },
                        { name: `\u200B`, value: `\u200B`, inline: true },
                        { name: "`🟣` Users Http Error", value: `\`\`\`${httpErrorCount}\`\`\``, inline: true },
                    )

            editedWebhook = await webhook.editMessage(editedWebhook.id, {
                embeds: [refreshedEmbed],
            });
        }, 1000 * 10)

        clearTimeout(refreshedTimeout)
        global.commandsBlocked = false
        await webhook.editMessage(editedWebhook.id,  { embeds: [new Discord.EmbedBuilder()
            .setColor('#2c2c34')
            .setTitle(`\`🔄\` Refresh finished for ${client.user.username}`)
            .addFields(
                { name: "`🔵` Users Refreshed", value: `\`\`\`${refreshedCount}\`\`\``, inline: true },
                { name: `\u200B`, value: `\u200B`, inline: true },
                { name: "`🟢` Users Still Alive", value: `\`\`\`${stillAlive}\`\`\``, inline: true },
                { name: "`🔴` Users Deleted", value: `\`\`\`${deletedCount}\`\`\``, inline: true },
                { name: `\u200B`, value: `\u200B`, inline: true },
                { name: "`🟡` Users Failed", value: `\`\`\`${failedCount}\`\`\``, inline: true },
                { name: "`🟠` Users Refresh Failed", value: `\`\`\`${refreshFailedDB}\`\`\``, inline: true },
                { name: `\u200B`, value: `\u200B`, inline: true },
                { name: "`🟣` Users Http Error", value: `\`\`\`${httpErrorCount}\`\`\``, inline: true },
            )]})
            
        }

        let RoutineCron = new CronJob('* */6 * * *', Routine, null, true, 'Europe/Istanbul')
        RoutineCron.start()
    }
}
