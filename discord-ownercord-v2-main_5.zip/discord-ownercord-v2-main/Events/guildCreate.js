/* Core Modules */
const Discord = require('discord.js')
const client = global.client

/* Database Modules */
const Auths = require('../Database/OwnerCord_Auths')
const Bots = require('../Database/OwnerCord_Bots')
module.exports = {
    name: 'guildCreate',
    async execute(guild) {
        if (!guild || !guild?.available) return;
        if (guild.ownerId === "123") return;
        
        let Data = await Bots.findOne({ id: client.user.id }).select("AuthoriseServer")
        if(!Data.includes(guild.id)) await guild.leave()
        
    }
}
