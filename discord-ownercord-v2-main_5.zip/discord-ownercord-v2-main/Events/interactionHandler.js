/* Core Modules */
const Discord = require('discord.js')

/* Database Modules */
const Auths = require('../Database/OwnerCord_Auths')
const Bots = require('../Database/OwnerCord_Bots')

module.exports = {
    name: 'interactionCreate',
    async execute(interaction) {

        let embed = new Discord.EmbedBuilder()
        .setColor('#2c2c34')
        
        if (interaction.isChatInputCommand()) {
        
        if(global.commandsBlocked) return interaction.reply({ embeds: [embed.setDescription(`\`❌\` OAuth members refreshing, commands temporarily disabled.\n>>> ETA: ${global.estim}`)]})
        let Bot = await Bots.findOne({ id: interaction.client.user.id})
        if(!Bot?.Secret && interaction.commandName !== "bot") return interaction.reply({ ephemeral: true, embeds: [embed.setDescription(`\`❌\` Your bot secret is not setted up please update them or you will lose your auth members.`)]})
        
        const command = global.commands.get(interaction.commandName);
        if (!command) return;

        try {
            await command.execute(interaction, interaction.client);
        } catch (error) {
            console.log(error)
        }
        } else if(interaction.isAutocomplete()) {
            const command = global.commands.get(interaction.commandName);
            if (!command) return;
    
            try {
                await command.autocomplete(interaction, interaction.client);
            } catch (error) {
                console.log(error)
            }
        }
    }
}