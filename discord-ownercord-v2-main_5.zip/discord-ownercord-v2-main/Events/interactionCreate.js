/* Core Modules */
const Discord = require('discord.js')
//const client = global.client

/* Database Modules */
const Auths = require('../Database/OwnerCord_Auths')
const Bots = require('../Database/OwnerCord_Bots')

module.exports = {
    name: 'interactionCreate',
    async execute(interaction) {

        let embed = new Discord.EmbedBuilder()
        .setColor('#2c2c34')
    
        if(interaction.customId === "roles") {
            await interaction.deferUpdate();

            await interaction.editReply({ components: [], embeds: [embed.setDescription(`\`✅\` Automatic roles set to **${(interaction.values[0].split("+")[0])}**`)]})

            let guild = interaction.client.guilds.cache.get(interaction.values[0].split("+")[2])
            if(!guild) return interaction.editReply({ components: [], embeds: [embed.setDescription(`\`⚠️\` I don't have access to the set server right now.`)]})
            let role = guild.roles.cache.get(interaction.values[0].split("+")[1])
            if(!role) return interaction.editReply({ components: [], embeds: [embed.setDescription(`\`⚠️\` There is no role on the set server.`)]})
            let Data = await Bots.findOne({ id: interaction.client.user.id })
            if(Data?.Features[0]?.Roles) await Bots.findOne({ id: interaction.client.user.id })
            else await Bots.findOneAndUpdate({ id: interaction.client.user.id }, { $push: { Roles: { guild: guild.id, role: role.id }}})

        }
    
    }
}