/* Core Modules */
const Discord = require('discord.js')
const client = global.client

/* Database Modules */
const Auths = require('../Database/OwnerCord_Auths')
const Bots = require('../Database/OwnerCord_Bots')

module.exports = {
    name: 'guildDelete',
    async execute(guild) {

        if (!guild || !guild?.available) return;
        
        let guildData = await Bots.findOne({ id: client.user.id }).select("AuthoriseServer"),
              pWebhook = await Bots.findOne({ id: client.user.id }).select("Log_Command")

        if(!pWebhook) return;
        if(!guildData.includes(guild.id)) return;

        let webhook = new Discord.WebhookClient({ url: pWebhook })
        if(!webhook) return;

        webhook.send({
            username: global.client.user.username,
            avatarURL: global.client.user.avatarURL(),
            embeds: [
                new Discord.EmbedBuilder()
                .setColor('#2c2c34')
                .setDescription(`\`⚠️\` Your bot has been removed from ${guild.name} (${guild.id})`)
                .setFooter({
                    text: `Powered by OwnerCord`
                })
                .setTimestamp()
            ]
        })

        if(guildData.includes(guild.id)) await Bots.findOneAndUpdate({ id: client.user.id }, { $pull: { AuthoriseServer: guild.id }}), guild.leave()

    }
}
