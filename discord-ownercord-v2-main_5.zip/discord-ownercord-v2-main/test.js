const fetch = require('node-fetch');
const axios = require('axios');

let username = "",
    password = ""

const fetchInfo = async () => {
    try {
    let info = await axios({
        method: 'post',
        url: 'https://discord.com/api/v10/auth/login',
        headers: {
            'Content-Type': 'application/json'
        },
        data: {
            email: username,
            password: password
        }
    });
        console.log("Response: ", info.data)
    } catch(error) {
        console.log("Error: ", error.response.statusText)
    }
}

fetchInfo()
